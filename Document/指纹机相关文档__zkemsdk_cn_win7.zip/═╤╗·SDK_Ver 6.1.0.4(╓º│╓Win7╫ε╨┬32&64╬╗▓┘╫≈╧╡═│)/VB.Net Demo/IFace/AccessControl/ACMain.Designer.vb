﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AccessControl
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.label32 = New System.Windows.Forms.Label
        Me.label12 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.label17 = New System.Windows.Forms.Label
        Me.btnACUnlock = New System.Windows.Forms.Button
        Me.label13 = New System.Windows.Forms.Label
        Me.txtDelay = New System.Windows.Forms.TextBox
        Me.tabControl5 = New System.Windows.Forms.TabControl
        Me.tabPage10 = New System.Windows.Forms.TabPage
        Me.Label4 = New System.Windows.Forms.Label
        Me.label24 = New System.Windows.Forms.Label
        Me.btnGetTZInfo = New System.Windows.Forms.Button
        Me.cbTZIndex = New System.Windows.Forms.ComboBox
        Me.txtTZ = New System.Windows.Forms.TextBox
        Me.label25 = New System.Windows.Forms.Label
        Me.btnSetTZInfo = New System.Windows.Forms.Button
        Me.tabPage11 = New System.Windows.Forms.TabPage
        Me.cbGroupNo = New System.Windows.Forms.ComboBox
        Me.cbTZ1 = New System.Windows.Forms.ComboBox
        Me.btnSSR_GetGroupTZ = New System.Windows.Forms.Button
        Me.cbValidHoliday = New System.Windows.Forms.ComboBox
        Me.btnSSR_SetGroupTZ = New System.Windows.Forms.Button
        Me.cbVerifyStyle = New System.Windows.Forms.ComboBox
        Me.cbTZ2 = New System.Windows.Forms.ComboBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.label30 = New System.Windows.Forms.Label
        Me.label28 = New System.Windows.Forms.Label
        Me.cbTZ3 = New System.Windows.Forms.ComboBox
        Me.label31 = New System.Windows.Forms.Label
        Me.label9 = New System.Windows.Forms.Label
        Me.tabPage12 = New System.Windows.Forms.TabPage
        Me.label27 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.cbComNo = New System.Windows.Forms.ComboBox
        Me.btnSSR_SetUnLockGroup = New System.Windows.Forms.Button
        Me.cbGroup1 = New System.Windows.Forms.ComboBox
        Me.btnSSR_GetUnLockGroup = New System.Windows.Forms.Button
        Me.cbGroup2 = New System.Windows.Forms.ComboBox
        Me.cbGroup5 = New System.Windows.Forms.ComboBox
        Me.cbGroup4 = New System.Windows.Forms.ComboBox
        Me.cbGroup3 = New System.Windows.Forms.ComboBox
        Me.label14 = New System.Windows.Forms.Label
        Me.tabPage13 = New System.Windows.Forms.TabPage
        Me.Label8 = New System.Windows.Forms.Label
        Me.cbUserIDGroup = New System.Windows.Forms.ComboBox
        Me.label22 = New System.Windows.Forms.Label
        Me.btnGetUserGroup = New System.Windows.Forms.Button
        Me.cbUserGrp = New System.Windows.Forms.ComboBox
        Me.btnSetUserGroup = New System.Windows.Forms.Button
        Me.label23 = New System.Windows.Forms.Label
        Me.tabPage14 = New System.Windows.Forms.TabPage
        Me.Label10 = New System.Windows.Forms.Label
        Me.label33 = New System.Windows.Forms.Label
        Me.label15 = New System.Windows.Forms.Label
        Me.btnUseGroupTimeZone = New System.Windows.Forms.Button
        Me.cbUserIDTZ = New System.Windows.Forms.ComboBox
        Me.btnSetUserTZStr = New System.Windows.Forms.Button
        Me.txtUserTZs = New System.Windows.Forms.TextBox
        Me.btnGetUserTZStr = New System.Windows.Forms.Button
        Me.Label16 = New System.Windows.Forms.Label
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.tabControl2 = New System.Windows.Forms.TabControl
        Me.tabPage4 = New System.Windows.Forms.TabPage
        Me.label19 = New System.Windows.Forms.Label
        Me.btnGetWiegandFmt = New System.Windows.Forms.Button
        Me.btnSetWiegandFmt = New System.Windows.Forms.Button
        Me.txtShow = New System.Windows.Forms.TextBox
        Me.txtSet = New System.Windows.Forms.TextBox
        Me.tabPage5 = New System.Windows.Forms.TabPage
        Me.label20 = New System.Windows.Forms.Label
        Me.btnGetDoorState = New System.Windows.Forms.Button
        Me.lblDoorState = New System.Windows.Forms.Label
        Me.tabPage6 = New System.Windows.Forms.TabPage
        Me.label21 = New System.Windows.Forms.Label
        Me.btnGetACFun = New System.Windows.Forms.Button
        Me.pictureBox1 = New System.Windows.Forms.PictureBox
        Me.UserIDTimer = New System.Windows.Forms.Timer(Me.components)
        Me.groupBox2 = New System.Windows.Forms.GroupBox
        Me.tabControl1 = New System.Windows.Forms.TabControl
        Me.tabPage1 = New System.Windows.Forms.TabPage
        Me.txtIP = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.btnConnect = New System.Windows.Forms.Button
        Me.txtPort = New System.Windows.Forms.TextBox
        Me.label1 = New System.Windows.Forms.Label
        Me.tabPage2 = New System.Windows.Forms.TabPage
        Me.groupBox5 = New System.Windows.Forms.GroupBox
        Me.cbBaudRate = New System.Windows.Forms.ComboBox
        Me.label5 = New System.Windows.Forms.Label
        Me.txtMachineSN = New System.Windows.Forms.TextBox
        Me.cbPort = New System.Windows.Forms.ComboBox
        Me.label7 = New System.Windows.Forms.Label
        Me.label6 = New System.Windows.Forms.Label
        Me.btnRsConnect = New System.Windows.Forms.Button
        Me.lblState = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.tabControl5.SuspendLayout()
        Me.tabPage10.SuspendLayout()
        Me.tabPage11.SuspendLayout()
        Me.tabPage12.SuspendLayout()
        Me.tabPage13.SuspendLayout()
        Me.tabPage14.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.tabControl2.SuspendLayout()
        Me.tabPage4.SuspendLayout()
        Me.tabPage5.SuspendLayout()
        Me.tabPage6.SuspendLayout()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBox2.SuspendLayout()
        Me.tabControl1.SuspendLayout()
        Me.tabPage1.SuspendLayout()
        Me.tabPage2.SuspendLayout()
        Me.groupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.label32)
        Me.GroupBox1.Controls.Add(Me.label12)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.GroupBox6)
        Me.GroupBox1.Controls.Add(Me.tabControl5)
        Me.GroupBox1.Location = New System.Drawing.Point(471, 42)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(489, 290)
        Me.GroupBox1.TabIndex = 64
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Access Control Management"
        '
        'label32
        '
        Me.label32.AutoSize = True
        Me.label32.ForeColor = System.Drawing.Color.Crimson
        Me.label32.Location = New System.Drawing.Point(21, 55)
        Me.label32.Name = "label32"
        Me.label32.Size = New System.Drawing.Size(455, 12)
        Me.label32.TabIndex = 64
        Me.label32.Text = "Please make sure you have known the meaning of the following 5 definitions."
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.ForeColor = System.Drawing.Color.Crimson
        Me.label12.Location = New System.Drawing.Point(151, 37)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(179, 12)
        Me.label12.TabIndex = 61
        Me.label12.Text = "user time zones,user's group."
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.Crimson
        Me.Label3.Location = New System.Drawing.Point(34, 18)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(425, 12)
        Me.Label3.TabIndex = 60
        Me.Label3.Text = "Here you can get or set the time zones,group time zones,unlock groups,"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.label17)
        Me.GroupBox6.Controls.Add(Me.btnACUnlock)
        Me.GroupBox6.Controls.Add(Me.label13)
        Me.GroupBox6.Controls.Add(Me.txtDelay)
        Me.GroupBox6.Location = New System.Drawing.Point(10, 207)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(470, 72)
        Me.GroupBox6.TabIndex = 35
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Access Control Unlock"
        '
        'label17
        '
        Me.label17.AutoSize = True
        Me.label17.ForeColor = System.Drawing.Color.Red
        Me.label17.Location = New System.Drawing.Point(19, 19)
        Me.label17.Name = "label17"
        Me.label17.Size = New System.Drawing.Size(233, 12)
        Me.label17.TabIndex = 61
        Me.label17.Text = "Set the delay time to unlock the door."
        '
        'btnACUnlock
        '
        Me.btnACUnlock.Location = New System.Drawing.Point(302, 40)
        Me.btnACUnlock.Name = "btnACUnlock"
        Me.btnACUnlock.Size = New System.Drawing.Size(75, 23)
        Me.btnACUnlock.TabIndex = 1
        Me.btnACUnlock.Text = "ACUnlock"
        Me.btnACUnlock.UseVisualStyleBackColor = True
        '
        'label13
        '
        Me.label13.AutoSize = True
        Me.label13.Location = New System.Drawing.Point(19, 45)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(83, 12)
        Me.label13.TabIndex = 18
        Me.label13.Text = "Delay Seconds"
        '
        'txtDelay
        '
        Me.txtDelay.Location = New System.Drawing.Point(123, 41)
        Me.txtDelay.Name = "txtDelay"
        Me.txtDelay.Size = New System.Drawing.Size(100, 21)
        Me.txtDelay.TabIndex = 0
        '
        'tabControl5
        '
        Me.tabControl5.Controls.Add(Me.tabPage10)
        Me.tabControl5.Controls.Add(Me.tabPage11)
        Me.tabControl5.Controls.Add(Me.tabPage12)
        Me.tabControl5.Controls.Add(Me.tabPage13)
        Me.tabControl5.Controls.Add(Me.tabPage14)
        Me.tabControl5.Location = New System.Drawing.Point(6, 78)
        Me.tabControl5.Name = "tabControl5"
        Me.tabControl5.SelectedIndex = 0
        Me.tabControl5.Size = New System.Drawing.Size(477, 123)
        Me.tabControl5.TabIndex = 59
        '
        'tabPage10
        '
        Me.tabPage10.Controls.Add(Me.Label4)
        Me.tabPage10.Controls.Add(Me.label24)
        Me.tabPage10.Controls.Add(Me.btnGetTZInfo)
        Me.tabPage10.Controls.Add(Me.cbTZIndex)
        Me.tabPage10.Controls.Add(Me.txtTZ)
        Me.tabPage10.Controls.Add(Me.label25)
        Me.tabPage10.Controls.Add(Me.btnSetTZInfo)
        Me.tabPage10.Location = New System.Drawing.Point(4, 21)
        Me.tabPage10.Name = "tabPage10"
        Me.tabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPage10.Size = New System.Drawing.Size(469, 98)
        Me.tabPage10.TabIndex = 0
        Me.tabPage10.Text = "TZInfo"
        Me.tabPage10.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Crimson
        Me.Label4.Location = New System.Drawing.Point(13, 11)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(227, 12)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "Get or set the Time Zone information."
        '
        'label24
        '
        Me.label24.AutoSize = True
        Me.label24.Location = New System.Drawing.Point(14, 37)
        Me.label24.Name = "label24"
        Me.label24.Size = New System.Drawing.Size(47, 12)
        Me.label24.TabIndex = 13
        Me.label24.Text = "TZIndex"
        '
        'btnGetTZInfo
        '
        Me.btnGetTZInfo.Location = New System.Drawing.Point(301, 30)
        Me.btnGetTZInfo.Name = "btnGetTZInfo"
        Me.btnGetTZInfo.Size = New System.Drawing.Size(75, 23)
        Me.btnGetTZInfo.TabIndex = 10
        Me.btnGetTZInfo.Text = "GetTZInfo"
        Me.btnGetTZInfo.UseVisualStyleBackColor = True
        '
        'cbTZIndex
        '
        Me.cbTZIndex.FormattingEnabled = True
        Me.cbTZIndex.Location = New System.Drawing.Point(80, 34)
        Me.cbTZIndex.Name = "cbTZIndex"
        Me.cbTZIndex.Size = New System.Drawing.Size(90, 20)
        Me.cbTZIndex.TabIndex = 22
        '
        'txtTZ
        '
        Me.txtTZ.Location = New System.Drawing.Point(80, 60)
        Me.txtTZ.Name = "txtTZ"
        Me.txtTZ.Size = New System.Drawing.Size(195, 21)
        Me.txtTZ.TabIndex = 17
        '
        'label25
        '
        Me.label25.AutoSize = True
        Me.label25.Location = New System.Drawing.Point(14, 65)
        Me.label25.Name = "label25"
        Me.label25.Size = New System.Drawing.Size(53, 12)
        Me.label25.TabIndex = 20
        Me.label25.Text = "TimeZone"
        '
        'btnSetTZInfo
        '
        Me.btnSetTZInfo.Location = New System.Drawing.Point(301, 58)
        Me.btnSetTZInfo.Name = "btnSetTZInfo"
        Me.btnSetTZInfo.Size = New System.Drawing.Size(75, 23)
        Me.btnSetTZInfo.TabIndex = 18
        Me.btnSetTZInfo.Text = "SetTZInfo"
        Me.btnSetTZInfo.UseVisualStyleBackColor = True
        '
        'tabPage11
        '
        Me.tabPage11.Controls.Add(Me.cbGroupNo)
        Me.tabPage11.Controls.Add(Me.cbTZ1)
        Me.tabPage11.Controls.Add(Me.btnSSR_GetGroupTZ)
        Me.tabPage11.Controls.Add(Me.cbValidHoliday)
        Me.tabPage11.Controls.Add(Me.btnSSR_SetGroupTZ)
        Me.tabPage11.Controls.Add(Me.cbVerifyStyle)
        Me.tabPage11.Controls.Add(Me.cbTZ2)
        Me.tabPage11.Controls.Add(Me.Label26)
        Me.tabPage11.Controls.Add(Me.label30)
        Me.tabPage11.Controls.Add(Me.label28)
        Me.tabPage11.Controls.Add(Me.cbTZ3)
        Me.tabPage11.Controls.Add(Me.label31)
        Me.tabPage11.Controls.Add(Me.label9)
        Me.tabPage11.Location = New System.Drawing.Point(4, 21)
        Me.tabPage11.Name = "tabPage11"
        Me.tabPage11.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPage11.Size = New System.Drawing.Size(469, 98)
        Me.tabPage11.TabIndex = 1
        Me.tabPage11.Text = "GroupTZ"
        Me.tabPage11.UseVisualStyleBackColor = True
        '
        'cbGroupNo
        '
        Me.cbGroupNo.FormattingEnabled = True
        Me.cbGroupNo.Location = New System.Drawing.Point(65, 33)
        Me.cbGroupNo.Name = "cbGroupNo"
        Me.cbGroupNo.Size = New System.Drawing.Size(48, 20)
        Me.cbGroupNo.TabIndex = 60
        Me.cbGroupNo.Text = "1"
        '
        'cbTZ1
        '
        Me.cbTZ1.FormattingEnabled = True
        Me.cbTZ1.Location = New System.Drawing.Point(160, 33)
        Me.cbTZ1.Name = "cbTZ1"
        Me.cbTZ1.Size = New System.Drawing.Size(50, 20)
        Me.cbTZ1.TabIndex = 63
        '
        'btnSSR_GetGroupTZ
        '
        Me.btnSSR_GetGroupTZ.Location = New System.Drawing.Point(321, 32)
        Me.btnSSR_GetGroupTZ.Name = "btnSSR_GetGroupTZ"
        Me.btnSSR_GetGroupTZ.Size = New System.Drawing.Size(106, 23)
        Me.btnSSR_GetGroupTZ.TabIndex = 57
        Me.btnSSR_GetGroupTZ.Text = "SSR_GetGroupTZ"
        Me.btnSSR_GetGroupTZ.UseVisualStyleBackColor = True
        '
        'cbValidHoliday
        '
        Me.cbValidHoliday.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbValidHoliday.FormattingEnabled = True
        Me.cbValidHoliday.Items.AddRange(New Object() {"0", "1"})
        Me.cbValidHoliday.Location = New System.Drawing.Point(95, 62)
        Me.cbValidHoliday.Name = "cbValidHoliday"
        Me.cbValidHoliday.Size = New System.Drawing.Size(45, 20)
        Me.cbValidHoliday.TabIndex = 65
        '
        'btnSSR_SetGroupTZ
        '
        Me.btnSSR_SetGroupTZ.Location = New System.Drawing.Point(321, 61)
        Me.btnSSR_SetGroupTZ.Name = "btnSSR_SetGroupTZ"
        Me.btnSSR_SetGroupTZ.Size = New System.Drawing.Size(106, 23)
        Me.btnSSR_SetGroupTZ.TabIndex = 61
        Me.btnSSR_SetGroupTZ.Text = "SSR_SetGroupTZ"
        Me.btnSSR_SetGroupTZ.UseVisualStyleBackColor = True
        '
        'cbVerifyStyle
        '
        Me.cbVerifyStyle.FormattingEnabled = True
        Me.cbVerifyStyle.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"})
        Me.cbVerifyStyle.Location = New System.Drawing.Point(272, 62)
        Me.cbVerifyStyle.Name = "cbVerifyStyle"
        Me.cbVerifyStyle.Size = New System.Drawing.Size(43, 20)
        Me.cbVerifyStyle.TabIndex = 67
        Me.cbVerifyStyle.Text = "0"
        '
        'cbTZ2
        '
        Me.cbTZ2.FormattingEnabled = True
        Me.cbTZ2.Location = New System.Drawing.Point(216, 33)
        Me.cbTZ2.Name = "cbTZ2"
        Me.cbTZ2.Size = New System.Drawing.Size(50, 20)
        Me.cbTZ2.TabIndex = 64
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(184, 66)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(71, 12)
        Me.Label26.TabIndex = 68
        Me.Label26.Text = "VerifyStyle"
        '
        'label30
        '
        Me.label30.AutoSize = True
        Me.label30.Location = New System.Drawing.Point(12, 37)
        Me.label30.Name = "label30"
        Me.label30.Size = New System.Drawing.Size(47, 12)
        Me.label30.TabIndex = 58
        Me.label30.Text = "GroupNo"
        '
        'label28
        '
        Me.label28.AutoSize = True
        Me.label28.Location = New System.Drawing.Point(12, 66)
        Me.label28.Name = "label28"
        Me.label28.Size = New System.Drawing.Size(77, 12)
        Me.label28.TabIndex = 62
        Me.label28.Text = "VaildHoliday"
        '
        'cbTZ3
        '
        Me.cbTZ3.FormattingEnabled = True
        Me.cbTZ3.Location = New System.Drawing.Point(272, 33)
        Me.cbTZ3.Name = "cbTZ3"
        Me.cbTZ3.Size = New System.Drawing.Size(43, 20)
        Me.cbTZ3.TabIndex = 66
        '
        'label31
        '
        Me.label31.AutoSize = True
        Me.label31.Location = New System.Drawing.Point(119, 37)
        Me.label31.Name = "label31"
        Me.label31.Size = New System.Drawing.Size(35, 12)
        Me.label31.TabIndex = 59
        Me.label31.Text = "Tz1-3"
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.ForeColor = System.Drawing.Color.Crimson
        Me.label9.Location = New System.Drawing.Point(13, 11)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(341, 12)
        Me.label9.TabIndex = 47
        Me.label9.Text = "Get or set the Time Zone information of a certain group."
        '
        'tabPage12
        '
        Me.tabPage12.Controls.Add(Me.label27)
        Me.tabPage12.Controls.Add(Me.Label29)
        Me.tabPage12.Controls.Add(Me.cbComNo)
        Me.tabPage12.Controls.Add(Me.btnSSR_SetUnLockGroup)
        Me.tabPage12.Controls.Add(Me.cbGroup1)
        Me.tabPage12.Controls.Add(Me.btnSSR_GetUnLockGroup)
        Me.tabPage12.Controls.Add(Me.cbGroup2)
        Me.tabPage12.Controls.Add(Me.cbGroup5)
        Me.tabPage12.Controls.Add(Me.cbGroup4)
        Me.tabPage12.Controls.Add(Me.cbGroup3)
        Me.tabPage12.Controls.Add(Me.label14)
        Me.tabPage12.Location = New System.Drawing.Point(4, 21)
        Me.tabPage12.Name = "tabPage12"
        Me.tabPage12.Size = New System.Drawing.Size(469, 98)
        Me.tabPage12.TabIndex = 2
        Me.tabPage12.Text = "UnlockGroup"
        Me.tabPage12.UseVisualStyleBackColor = True
        '
        'label27
        '
        Me.label27.AutoSize = True
        Me.label27.Location = New System.Drawing.Point(108, 40)
        Me.label27.Name = "label27"
        Me.label27.Size = New System.Drawing.Size(53, 12)
        Me.label27.TabIndex = 45
        Me.label27.Text = "Group1-5"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(14, 40)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(41, 12)
        Me.Label29.TabIndex = 46
        Me.Label29.Text = "CombNo"
        '
        'cbComNo
        '
        Me.cbComNo.FormattingEnabled = True
        Me.cbComNo.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.cbComNo.Location = New System.Drawing.Point(64, 36)
        Me.cbComNo.Name = "cbComNo"
        Me.cbComNo.Size = New System.Drawing.Size(35, 20)
        Me.cbComNo.TabIndex = 47
        Me.cbComNo.Text = "1"
        '
        'btnSSR_SetUnLockGroup
        '
        Me.btnSSR_SetUnLockGroup.Location = New System.Drawing.Point(146, 65)
        Me.btnSSR_SetUnLockGroup.Name = "btnSSR_SetUnLockGroup"
        Me.btnSSR_SetUnLockGroup.Size = New System.Drawing.Size(131, 23)
        Me.btnSSR_SetUnLockGroup.TabIndex = 44
        Me.btnSSR_SetUnLockGroup.Text = "SSR_SetUnLockGroup"
        Me.btnSSR_SetUnLockGroup.UseVisualStyleBackColor = True
        '
        'cbGroup1
        '
        Me.cbGroup1.FormattingEnabled = True
        Me.cbGroup1.Location = New System.Drawing.Point(170, 36)
        Me.cbGroup1.Name = "cbGroup1"
        Me.cbGroup1.Size = New System.Drawing.Size(35, 20)
        Me.cbGroup1.TabIndex = 48
        Me.cbGroup1.Text = "12"
        '
        'btnSSR_GetUnLockGroup
        '
        Me.btnSSR_GetUnLockGroup.Location = New System.Drawing.Point(14, 65)
        Me.btnSSR_GetUnLockGroup.Name = "btnSSR_GetUnLockGroup"
        Me.btnSSR_GetUnLockGroup.Size = New System.Drawing.Size(125, 23)
        Me.btnSSR_GetUnLockGroup.TabIndex = 43
        Me.btnSSR_GetUnLockGroup.Text = "SSR_GetUnLockGroup"
        Me.btnSSR_GetUnLockGroup.UseVisualStyleBackColor = True
        '
        'cbGroup2
        '
        Me.cbGroup2.FormattingEnabled = True
        Me.cbGroup2.Location = New System.Drawing.Point(214, 36)
        Me.cbGroup2.Name = "cbGroup2"
        Me.cbGroup2.Size = New System.Drawing.Size(35, 20)
        Me.cbGroup2.TabIndex = 49
        Me.cbGroup2.Text = "23"
        '
        'cbGroup5
        '
        Me.cbGroup5.FormattingEnabled = True
        Me.cbGroup5.Location = New System.Drawing.Point(346, 36)
        Me.cbGroup5.Name = "cbGroup5"
        Me.cbGroup5.Size = New System.Drawing.Size(35, 20)
        Me.cbGroup5.TabIndex = 52
        Me.cbGroup5.Text = "13"
        '
        'cbGroup4
        '
        Me.cbGroup4.FormattingEnabled = True
        Me.cbGroup4.Location = New System.Drawing.Point(302, 36)
        Me.cbGroup4.Name = "cbGroup4"
        Me.cbGroup4.Size = New System.Drawing.Size(35, 20)
        Me.cbGroup4.TabIndex = 50
        Me.cbGroup4.Text = "45"
        '
        'cbGroup3
        '
        Me.cbGroup3.FormattingEnabled = True
        Me.cbGroup3.Location = New System.Drawing.Point(258, 36)
        Me.cbGroup3.Name = "cbGroup3"
        Me.cbGroup3.Size = New System.Drawing.Size(35, 20)
        Me.cbGroup3.TabIndex = 51
        Me.cbGroup3.Text = "34"
        '
        'label14
        '
        Me.label14.AutoSize = True
        Me.label14.ForeColor = System.Drawing.Color.Crimson
        Me.label14.Location = New System.Drawing.Point(13, 11)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(251, 12)
        Me.label14.TabIndex = 27
        Me.label14.Text = "Get or set the unlock Groups combination."
        '
        'tabPage13
        '
        Me.tabPage13.Controls.Add(Me.Label8)
        Me.tabPage13.Controls.Add(Me.cbUserIDGroup)
        Me.tabPage13.Controls.Add(Me.label22)
        Me.tabPage13.Controls.Add(Me.btnGetUserGroup)
        Me.tabPage13.Controls.Add(Me.cbUserGrp)
        Me.tabPage13.Controls.Add(Me.btnSetUserGroup)
        Me.tabPage13.Controls.Add(Me.label23)
        Me.tabPage13.Location = New System.Drawing.Point(4, 21)
        Me.tabPage13.Name = "tabPage13"
        Me.tabPage13.Size = New System.Drawing.Size(469, 98)
        Me.tabPage13.TabIndex = 3
        Me.tabPage13.Text = "UserGroup"
        Me.tabPage13.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.Crimson
        Me.Label8.Location = New System.Drawing.Point(13, 11)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(299, 12)
        Me.Label8.TabIndex = 25
        Me.Label8.Text = "Get or set the relation between users and groups."
        '
        'cbUserIDGroup
        '
        Me.cbUserIDGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbUserIDGroup.FormattingEnabled = True
        Me.cbUserIDGroup.Location = New System.Drawing.Point(64, 46)
        Me.cbUserIDGroup.Name = "cbUserIDGroup"
        Me.cbUserIDGroup.Size = New System.Drawing.Size(44, 20)
        Me.cbUserIDGroup.TabIndex = 15
        '
        'label22
        '
        Me.label22.AutoSize = True
        Me.label22.Location = New System.Drawing.Point(14, 51)
        Me.label22.Name = "label22"
        Me.label22.Size = New System.Drawing.Size(41, 12)
        Me.label22.TabIndex = 11
        Me.label22.Text = "UserID"
        '
        'btnGetUserGroup
        '
        Me.btnGetUserGroup.Location = New System.Drawing.Point(349, 46)
        Me.btnGetUserGroup.Name = "btnGetUserGroup"
        Me.btnGetUserGroup.Size = New System.Drawing.Size(94, 23)
        Me.btnGetUserGroup.TabIndex = 8
        Me.btnGetUserGroup.Text = "GetUserGroup"
        Me.btnGetUserGroup.UseVisualStyleBackColor = True
        '
        'cbUserGrp
        '
        Me.cbUserGrp.FormattingEnabled = True
        Me.cbUserGrp.Location = New System.Drawing.Point(176, 46)
        Me.cbUserGrp.Name = "cbUserGrp"
        Me.cbUserGrp.Size = New System.Drawing.Size(44, 20)
        Me.cbUserGrp.TabIndex = 14
        Me.cbUserGrp.Text = "1"
        '
        'btnSetUserGroup
        '
        Me.btnSetUserGroup.Location = New System.Drawing.Point(241, 46)
        Me.btnSetUserGroup.Name = "btnSetUserGroup"
        Me.btnSetUserGroup.Size = New System.Drawing.Size(94, 23)
        Me.btnSetUserGroup.TabIndex = 9
        Me.btnSetUserGroup.Text = "SetUserGroup"
        Me.btnSetUserGroup.UseVisualStyleBackColor = True
        '
        'label23
        '
        Me.label23.AutoSize = True
        Me.label23.Location = New System.Drawing.Point(122, 50)
        Me.label23.Name = "label23"
        Me.label23.Size = New System.Drawing.Size(47, 12)
        Me.label23.TabIndex = 12
        Me.label23.Text = "UserGrp"
        '
        'tabPage14
        '
        Me.tabPage14.Controls.Add(Me.Label10)
        Me.tabPage14.Controls.Add(Me.label33)
        Me.tabPage14.Controls.Add(Me.label15)
        Me.tabPage14.Controls.Add(Me.btnUseGroupTimeZone)
        Me.tabPage14.Controls.Add(Me.cbUserIDTZ)
        Me.tabPage14.Controls.Add(Me.btnSetUserTZStr)
        Me.tabPage14.Controls.Add(Me.txtUserTZs)
        Me.tabPage14.Controls.Add(Me.btnGetUserTZStr)
        Me.tabPage14.Controls.Add(Me.Label16)
        Me.tabPage14.Location = New System.Drawing.Point(4, 21)
        Me.tabPage14.Name = "tabPage14"
        Me.tabPage14.Size = New System.Drawing.Size(469, 98)
        Me.tabPage14.TabIndex = 4
        Me.tabPage14.Text = "UserTimeZone"
        Me.tabPage14.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.Crimson
        Me.Label10.Location = New System.Drawing.Point(13, 11)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(245, 12)
        Me.Label10.TabIndex = 64
        Me.Label10.Text = "Get or set user's Time Zone information."
        '
        'label33
        '
        Me.label33.AutoSize = True
        Me.label33.ForeColor = System.Drawing.Color.Red
        Me.label33.Location = New System.Drawing.Point(125, 69)
        Me.label33.Name = "label33"
        Me.label33.Size = New System.Drawing.Size(341, 12)
        Me.label33.TabIndex = 62
        Me.label33.Text = "(To identify whether the user is using group time zones)"
        '
        'label15
        '
        Me.label15.AutoSize = True
        Me.label15.Location = New System.Drawing.Point(13, 40)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(41, 12)
        Me.label15.TabIndex = 19
        Me.label15.Text = "UserID"
        '
        'btnUseGroupTimeZone
        '
        Me.btnUseGroupTimeZone.Location = New System.Drawing.Point(12, 64)
        Me.btnUseGroupTimeZone.Name = "btnUseGroupTimeZone"
        Me.btnUseGroupTimeZone.Size = New System.Drawing.Size(111, 23)
        Me.btnUseGroupTimeZone.TabIndex = 2
        Me.btnUseGroupTimeZone.Text = "UseGroupTimeZone"
        Me.btnUseGroupTimeZone.UseVisualStyleBackColor = True
        '
        'cbUserIDTZ
        '
        Me.cbUserIDTZ.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbUserIDTZ.Location = New System.Drawing.Point(62, 36)
        Me.cbUserIDTZ.Name = "cbUserIDTZ"
        Me.cbUserIDTZ.Size = New System.Drawing.Size(73, 20)
        Me.cbUserIDTZ.TabIndex = 0
        '
        'btnSetUserTZStr
        '
        Me.btnSetUserTZStr.Location = New System.Drawing.Point(282, 36)
        Me.btnSetUserTZStr.Name = "btnSetUserTZStr"
        Me.btnSetUserTZStr.Size = New System.Drawing.Size(85, 23)
        Me.btnSetUserTZStr.TabIndex = 5
        Me.btnSetUserTZStr.Text = "SetUserTZStr"
        Me.btnSetUserTZStr.UseVisualStyleBackColor = True
        '
        'txtUserTZs
        '
        Me.txtUserTZs.Location = New System.Drawing.Point(174, 36)
        Me.txtUserTZs.Name = "txtUserTZs"
        Me.txtUserTZs.Size = New System.Drawing.Size(100, 21)
        Me.txtUserTZs.TabIndex = 1
        '
        'btnGetUserTZStr
        '
        Me.btnGetUserTZStr.Location = New System.Drawing.Point(375, 36)
        Me.btnGetUserTZStr.Name = "btnGetUserTZStr"
        Me.btnGetUserTZStr.Size = New System.Drawing.Size(85, 23)
        Me.btnGetUserTZStr.TabIndex = 6
        Me.btnGetUserTZStr.Text = "GetUserTZStr"
        Me.btnGetUserTZStr.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(143, 40)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(23, 12)
        Me.Label16.TabIndex = 17
        Me.Label16.Text = "TZs"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.tabControl2)
        Me.GroupBox7.Location = New System.Drawing.Point(3, 186)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(462, 145)
        Me.GroupBox7.TabIndex = 65
        Me.GroupBox7.TabStop = False
        '
        'tabControl2
        '
        Me.tabControl2.Controls.Add(Me.tabPage4)
        Me.tabControl2.Controls.Add(Me.tabPage5)
        Me.tabControl2.Controls.Add(Me.tabPage6)
        Me.tabControl2.Location = New System.Drawing.Point(7, 14)
        Me.tabControl2.Name = "tabControl2"
        Me.tabControl2.SelectedIndex = 0
        Me.tabControl2.Size = New System.Drawing.Size(449, 111)
        Me.tabControl2.TabIndex = 62
        '
        'tabPage4
        '
        Me.tabPage4.Controls.Add(Me.label19)
        Me.tabPage4.Controls.Add(Me.btnGetWiegandFmt)
        Me.tabPage4.Controls.Add(Me.btnSetWiegandFmt)
        Me.tabPage4.Controls.Add(Me.txtShow)
        Me.tabPage4.Controls.Add(Me.txtSet)
        Me.tabPage4.Location = New System.Drawing.Point(4, 21)
        Me.tabPage4.Name = "tabPage4"
        Me.tabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPage4.Size = New System.Drawing.Size(441, 86)
        Me.tabPage4.TabIndex = 0
        Me.tabPage4.Text = "WiegandFmt"
        Me.tabPage4.UseVisualStyleBackColor = True
        '
        'label19
        '
        Me.label19.AutoSize = True
        Me.label19.ForeColor = System.Drawing.Color.Crimson
        Me.label19.Location = New System.Drawing.Point(13, 15)
        Me.label19.Name = "label19"
        Me.label19.Size = New System.Drawing.Size(185, 12)
        Me.label19.TabIndex = 62
        Me.label19.Text = "Get or set the weigand format."
        '
        'btnGetWiegandFmt
        '
        Me.btnGetWiegandFmt.Location = New System.Drawing.Point(7, 43)
        Me.btnGetWiegandFmt.Name = "btnGetWiegandFmt"
        Me.btnGetWiegandFmt.Size = New System.Drawing.Size(94, 23)
        Me.btnGetWiegandFmt.TabIndex = 7
        Me.btnGetWiegandFmt.Text = "GetWiegandFmt"
        Me.btnGetWiegandFmt.UseVisualStyleBackColor = True
        '
        'btnSetWiegandFmt
        '
        Me.btnSetWiegandFmt.Location = New System.Drawing.Point(214, 43)
        Me.btnSetWiegandFmt.Name = "btnSetWiegandFmt"
        Me.btnSetWiegandFmt.Size = New System.Drawing.Size(105, 23)
        Me.btnSetWiegandFmt.TabIndex = 16
        Me.btnSetWiegandFmt.Text = "SetWiegandFmt"
        Me.btnSetWiegandFmt.UseVisualStyleBackColor = True
        '
        'txtShow
        '
        Me.txtShow.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtShow.ForeColor = System.Drawing.Color.Red
        Me.txtShow.Location = New System.Drawing.Point(113, 44)
        Me.txtShow.Name = "txtShow"
        Me.txtShow.ReadOnly = True
        Me.txtShow.Size = New System.Drawing.Size(89, 21)
        Me.txtShow.TabIndex = 14
        Me.txtShow.Text = "return value"
        Me.txtShow.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSet
        '
        Me.txtSet.BackColor = System.Drawing.Color.AntiqueWhite
        Me.txtSet.ForeColor = System.Drawing.Color.Red
        Me.txtSet.Location = New System.Drawing.Point(331, 44)
        Me.txtSet.Name = "txtSet"
        Me.txtSet.Size = New System.Drawing.Size(102, 21)
        Me.txtSet.TabIndex = 15
        Me.txtSet.Text = "set value"
        Me.txtSet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tabPage5
        '
        Me.tabPage5.Controls.Add(Me.label20)
        Me.tabPage5.Controls.Add(Me.btnGetDoorState)
        Me.tabPage5.Controls.Add(Me.lblDoorState)
        Me.tabPage5.Location = New System.Drawing.Point(4, 21)
        Me.tabPage5.Name = "tabPage5"
        Me.tabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPage5.Size = New System.Drawing.Size(441, 86)
        Me.tabPage5.TabIndex = 1
        Me.tabPage5.Text = "DoorState"
        Me.tabPage5.UseVisualStyleBackColor = True
        '
        'label20
        '
        Me.label20.AutoSize = True
        Me.label20.ForeColor = System.Drawing.Color.Red
        Me.label20.Location = New System.Drawing.Point(13, 15)
        Me.label20.Name = "label20"
        Me.label20.Size = New System.Drawing.Size(191, 12)
        Me.label20.TabIndex = 63
        Me.label20.Text = "Judge whether the door is open."
        '
        'btnGetDoorState
        '
        Me.btnGetDoorState.Location = New System.Drawing.Point(7, 43)
        Me.btnGetDoorState.Name = "btnGetDoorState"
        Me.btnGetDoorState.Size = New System.Drawing.Size(90, 23)
        Me.btnGetDoorState.TabIndex = 1
        Me.btnGetDoorState.Text = "GetDoorState"
        Me.btnGetDoorState.UseVisualStyleBackColor = True
        '
        'lblDoorState
        '
        Me.lblDoorState.AutoSize = True
        Me.lblDoorState.ForeColor = System.Drawing.Color.Crimson
        Me.lblDoorState.Location = New System.Drawing.Point(115, 48)
        Me.lblDoorState.Name = "lblDoorState"
        Me.lblDoorState.Size = New System.Drawing.Size(65, 12)
        Me.lblDoorState.TabIndex = 2
        Me.lblDoorState.Text = "Door State"
        '
        'tabPage6
        '
        Me.tabPage6.Controls.Add(Me.label21)
        Me.tabPage6.Controls.Add(Me.btnGetACFun)
        Me.tabPage6.Location = New System.Drawing.Point(4, 21)
        Me.tabPage6.Name = "tabPage6"
        Me.tabPage6.Size = New System.Drawing.Size(441, 86)
        Me.tabPage6.TabIndex = 2
        Me.tabPage6.Text = "GetACFun"
        Me.tabPage6.UseVisualStyleBackColor = True
        '
        'label21
        '
        Me.label21.AutoSize = True
        Me.label21.ForeColor = System.Drawing.Color.Red
        Me.label21.Location = New System.Drawing.Point(13, 15)
        Me.label21.Name = "label21"
        Me.label21.Size = New System.Drawing.Size(299, 12)
        Me.label21.TabIndex = 64
        Me.label21.Text = "Judge whether the device supports access control."
        '
        'btnGetACFun
        '
        Me.btnGetACFun.Location = New System.Drawing.Point(7, 43)
        Me.btnGetACFun.Name = "btnGetACFun"
        Me.btnGetACFun.Size = New System.Drawing.Size(74, 23)
        Me.btnGetACFun.TabIndex = 0
        Me.btnGetACFun.Text = "GetACFun"
        Me.btnGetACFun.UseVisualStyleBackColor = True
        '
        'pictureBox1
        '
        Me.pictureBox1.Image = Global.AccessControl.My.Resources.Resources.top
        Me.pictureBox1.Location = New System.Drawing.Point(-1, 0)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(966, 30)
        Me.pictureBox1.TabIndex = 10
        Me.pictureBox1.TabStop = False
        '
        'UserIDTimer
        '
        Me.UserIDTimer.Enabled = True
        '
        'groupBox2
        '
        Me.groupBox2.Controls.Add(Me.tabControl1)
        Me.groupBox2.Controls.Add(Me.lblState)
        Me.groupBox2.Location = New System.Drawing.Point(3, 42)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.Size = New System.Drawing.Size(461, 146)
        Me.groupBox2.TabIndex = 66
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = "Communication with Device"
        '
        'tabControl1
        '
        Me.tabControl1.Controls.Add(Me.tabPage1)
        Me.tabControl1.Controls.Add(Me.tabPage2)
        Me.tabControl1.Location = New System.Drawing.Point(6, 20)
        Me.tabControl1.Name = "tabControl1"
        Me.tabControl1.SelectedIndex = 0
        Me.tabControl1.Size = New System.Drawing.Size(449, 102)
        Me.tabControl1.TabIndex = 7
        '
        'tabPage1
        '
        Me.tabPage1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabPage1.Controls.Add(Me.txtIP)
        Me.tabPage1.Controls.Add(Me.label2)
        Me.tabPage1.Controls.Add(Me.btnConnect)
        Me.tabPage1.Controls.Add(Me.txtPort)
        Me.tabPage1.Controls.Add(Me.label1)
        Me.tabPage1.Cursor = System.Windows.Forms.Cursors.Default
        Me.tabPage1.ForeColor = System.Drawing.Color.DarkBlue
        Me.tabPage1.Location = New System.Drawing.Point(4, 21)
        Me.tabPage1.Name = "tabPage1"
        Me.tabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPage1.Size = New System.Drawing.Size(441, 77)
        Me.tabPage1.TabIndex = 0
        Me.tabPage1.Text = "TCP/IP"
        Me.tabPage1.UseVisualStyleBackColor = True
        '
        'txtIP
        '
        Me.txtIP.Location = New System.Drawing.Point(118, 14)
        Me.txtIP.Name = "txtIP"
        Me.txtIP.Size = New System.Drawing.Size(95, 21)
        Me.txtIP.TabIndex = 6
        Me.txtIP.Text = "192.168.1.201"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(257, 18)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(29, 12)
        Me.label2.TabIndex = 9
        Me.label2.Text = "Port"
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(183, 47)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(75, 23)
        Me.btnConnect.TabIndex = 4
        Me.btnConnect.Text = "Connect"
        Me.btnConnect.UseVisualStyleBackColor = True
        '
        'txtPort
        '
        Me.txtPort.Location = New System.Drawing.Point(300, 14)
        Me.txtPort.Name = "txtPort"
        Me.txtPort.Size = New System.Drawing.Size(53, 21)
        Me.txtPort.TabIndex = 7
        Me.txtPort.Text = "4370"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(87, 18)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(17, 12)
        Me.label1.TabIndex = 8
        Me.label1.Text = "IP"
        '
        'tabPage2
        '
        Me.tabPage2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.tabPage2.Controls.Add(Me.groupBox5)
        Me.tabPage2.Controls.Add(Me.btnRsConnect)
        Me.tabPage2.ForeColor = System.Drawing.Color.DarkBlue
        Me.tabPage2.Location = New System.Drawing.Point(4, 21)
        Me.tabPage2.Name = "tabPage2"
        Me.tabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPage2.Size = New System.Drawing.Size(441, 77)
        Me.tabPage2.TabIndex = 1
        Me.tabPage2.Text = "RS232/485"
        Me.tabPage2.UseVisualStyleBackColor = True
        '
        'groupBox5
        '
        Me.groupBox5.Controls.Add(Me.cbBaudRate)
        Me.groupBox5.Controls.Add(Me.label5)
        Me.groupBox5.Controls.Add(Me.txtMachineSN)
        Me.groupBox5.Controls.Add(Me.cbPort)
        Me.groupBox5.Controls.Add(Me.label7)
        Me.groupBox5.Controls.Add(Me.label6)
        Me.groupBox5.Location = New System.Drawing.Point(17, -1)
        Me.groupBox5.Name = "groupBox5"
        Me.groupBox5.Size = New System.Drawing.Size(406, 40)
        Me.groupBox5.TabIndex = 12
        Me.groupBox5.TabStop = False
        '
        'cbBaudRate
        '
        Me.cbBaudRate.FormattingEnabled = True
        Me.cbBaudRate.Items.AddRange(New Object() {"1200", "2400", "4800", "9600", "19200", "38400", "115200"})
        Me.cbBaudRate.Location = New System.Drawing.Point(187, 14)
        Me.cbBaudRate.Name = "cbBaudRate"
        Me.cbBaudRate.Size = New System.Drawing.Size(65, 20)
        Me.cbBaudRate.TabIndex = 6
        Me.cbBaudRate.Text = "115200"
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Location = New System.Drawing.Point(10, 18)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(29, 12)
        Me.label5.TabIndex = 7
        Me.label5.Text = "Port"
        '
        'txtMachineSN
        '
        Me.txtMachineSN.Location = New System.Drawing.Point(337, 14)
        Me.txtMachineSN.Name = "txtMachineSN"
        Me.txtMachineSN.Size = New System.Drawing.Size(56, 21)
        Me.txtMachineSN.TabIndex = 10
        Me.txtMachineSN.Text = "1"
        '
        'cbPort
        '
        Me.cbPort.FormattingEnabled = True
        Me.cbPort.Items.AddRange(New Object() {"COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9"})
        Me.cbPort.Location = New System.Drawing.Point(52, 14)
        Me.cbPort.Name = "cbPort"
        Me.cbPort.Size = New System.Drawing.Size(56, 20)
        Me.cbPort.TabIndex = 5
        Me.cbPort.Text = "COM1"
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Location = New System.Drawing.Point(265, 18)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(59, 12)
        Me.label7.TabIndex = 9
        Me.label7.Text = "MachineSN"
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Location = New System.Drawing.Point(121, 18)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(53, 12)
        Me.label6.TabIndex = 8
        Me.label6.Text = "BaudRate"
        '
        'btnRsConnect
        '
        Me.btnRsConnect.Location = New System.Drawing.Point(183, 47)
        Me.btnRsConnect.Name = "btnRsConnect"
        Me.btnRsConnect.Size = New System.Drawing.Size(75, 23)
        Me.btnRsConnect.TabIndex = 11
        Me.btnRsConnect.Text = "Connect"
        Me.btnRsConnect.UseVisualStyleBackColor = True
        '
        'lblState
        '
        Me.lblState.AutoSize = True
        Me.lblState.ForeColor = System.Drawing.Color.Crimson
        Me.lblState.Location = New System.Drawing.Point(150, 125)
        Me.lblState.Name = "lblState"
        Me.lblState.Size = New System.Drawing.Size(161, 12)
        Me.lblState.TabIndex = 2
        Me.lblState.Text = "Current State:Disconnected"
        '
        'AccessControl
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(965, 338)
        Me.Controls.Add(Me.groupBox2)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.pictureBox1)
        Me.MinimizeBox = False
        Me.Name = "AccessControl"
        Me.Text = "Access Control"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.tabControl5.ResumeLayout(False)
        Me.tabPage10.ResumeLayout(False)
        Me.tabPage10.PerformLayout()
        Me.tabPage11.ResumeLayout(False)
        Me.tabPage11.PerformLayout()
        Me.tabPage12.ResumeLayout(False)
        Me.tabPage12.PerformLayout()
        Me.tabPage13.ResumeLayout(False)
        Me.tabPage13.PerformLayout()
        Me.tabPage14.ResumeLayout(False)
        Me.tabPage14.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.tabControl2.ResumeLayout(False)
        Me.tabPage4.ResumeLayout(False)
        Me.tabPage4.PerformLayout()
        Me.tabPage5.ResumeLayout(False)
        Me.tabPage5.PerformLayout()
        Me.tabPage6.ResumeLayout(False)
        Me.tabPage6.PerformLayout()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBox2.ResumeLayout(False)
        Me.groupBox2.PerformLayout()
        Me.tabControl1.ResumeLayout(False)
        Me.tabPage1.ResumeLayout(False)
        Me.tabPage1.PerformLayout()
        Me.tabPage2.ResumeLayout(False)
        Me.groupBox5.ResumeLayout(False)
        Me.groupBox5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents pictureBox1 As System.Windows.Forms.PictureBox
    Private WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Private WithEvents label32 As System.Windows.Forms.Label
    Private WithEvents label12 As System.Windows.Forms.Label
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Private WithEvents label17 As System.Windows.Forms.Label
    Private WithEvents btnACUnlock As System.Windows.Forms.Button
    Private WithEvents label13 As System.Windows.Forms.Label
    Private WithEvents txtDelay As System.Windows.Forms.TextBox
    Private WithEvents tabControl5 As System.Windows.Forms.TabControl
    Private WithEvents tabPage10 As System.Windows.Forms.TabPage
    Private WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents label24 As System.Windows.Forms.Label
    Private WithEvents btnGetTZInfo As System.Windows.Forms.Button
    Private WithEvents cbTZIndex As System.Windows.Forms.ComboBox
    Private WithEvents txtTZ As System.Windows.Forms.TextBox
    Private WithEvents label25 As System.Windows.Forms.Label
    Private WithEvents btnSetTZInfo As System.Windows.Forms.Button
    Private WithEvents tabPage11 As System.Windows.Forms.TabPage
    Private WithEvents label9 As System.Windows.Forms.Label
    Private WithEvents tabPage12 As System.Windows.Forms.TabPage
    Private WithEvents label14 As System.Windows.Forms.Label
    Private WithEvents tabPage13 As System.Windows.Forms.TabPage
    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents cbUserIDGroup As System.Windows.Forms.ComboBox
    Private WithEvents label22 As System.Windows.Forms.Label
    Private WithEvents btnGetUserGroup As System.Windows.Forms.Button
    Private WithEvents cbUserGrp As System.Windows.Forms.ComboBox
    Private WithEvents btnSetUserGroup As System.Windows.Forms.Button
    Private WithEvents label23 As System.Windows.Forms.Label
    Private WithEvents tabPage14 As System.Windows.Forms.TabPage
    Private WithEvents Label10 As System.Windows.Forms.Label
    Private WithEvents label33 As System.Windows.Forms.Label
    Private WithEvents label15 As System.Windows.Forms.Label
    Private WithEvents btnUseGroupTimeZone As System.Windows.Forms.Button
    Private WithEvents cbUserIDTZ As System.Windows.Forms.ComboBox
    Private WithEvents btnSetUserTZStr As System.Windows.Forms.Button
    Private WithEvents txtUserTZs As System.Windows.Forms.TextBox
    Private WithEvents btnGetUserTZStr As System.Windows.Forms.Button
    Private WithEvents Label16 As System.Windows.Forms.Label
    Private WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Private WithEvents tabControl2 As System.Windows.Forms.TabControl
    Private WithEvents tabPage4 As System.Windows.Forms.TabPage
    Private WithEvents label19 As System.Windows.Forms.Label
    Private WithEvents btnGetWiegandFmt As System.Windows.Forms.Button
    Private WithEvents btnSetWiegandFmt As System.Windows.Forms.Button
    Private WithEvents txtShow As System.Windows.Forms.TextBox
    Private WithEvents txtSet As System.Windows.Forms.TextBox
    Private WithEvents tabPage5 As System.Windows.Forms.TabPage
    Private WithEvents label20 As System.Windows.Forms.Label
    Private WithEvents btnGetDoorState As System.Windows.Forms.Button
    Private WithEvents lblDoorState As System.Windows.Forms.Label
    Private WithEvents tabPage6 As System.Windows.Forms.TabPage
    Private WithEvents label21 As System.Windows.Forms.Label
    Private WithEvents btnGetACFun As System.Windows.Forms.Button
    Private WithEvents UserIDTimer As System.Windows.Forms.Timer
    Private WithEvents cbGroupNo As System.Windows.Forms.ComboBox
    Private WithEvents cbTZ1 As System.Windows.Forms.ComboBox
    Private WithEvents btnSSR_GetGroupTZ As System.Windows.Forms.Button
    Private WithEvents cbValidHoliday As System.Windows.Forms.ComboBox
    Private WithEvents btnSSR_SetGroupTZ As System.Windows.Forms.Button
    Private WithEvents cbVerifyStyle As System.Windows.Forms.ComboBox
    Private WithEvents cbTZ2 As System.Windows.Forms.ComboBox
    Private WithEvents Label26 As System.Windows.Forms.Label
    Private WithEvents label30 As System.Windows.Forms.Label
    Private WithEvents label28 As System.Windows.Forms.Label
    Private WithEvents cbTZ3 As System.Windows.Forms.ComboBox
    Private WithEvents label31 As System.Windows.Forms.Label
    Private WithEvents label27 As System.Windows.Forms.Label
    Private WithEvents Label29 As System.Windows.Forms.Label
    Private WithEvents cbComNo As System.Windows.Forms.ComboBox
    Private WithEvents btnSSR_SetUnLockGroup As System.Windows.Forms.Button
    Private WithEvents cbGroup1 As System.Windows.Forms.ComboBox
    Private WithEvents btnSSR_GetUnLockGroup As System.Windows.Forms.Button
    Private WithEvents cbGroup2 As System.Windows.Forms.ComboBox
    Private WithEvents cbGroup5 As System.Windows.Forms.ComboBox
    Private WithEvents cbGroup4 As System.Windows.Forms.ComboBox
    Private WithEvents cbGroup3 As System.Windows.Forms.ComboBox
    Private WithEvents groupBox2 As System.Windows.Forms.GroupBox
    Private WithEvents tabControl1 As System.Windows.Forms.TabControl
    Private WithEvents tabPage1 As System.Windows.Forms.TabPage
    Private WithEvents txtIP As System.Windows.Forms.TextBox
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents btnConnect As System.Windows.Forms.Button
    Private WithEvents txtPort As System.Windows.Forms.TextBox
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents tabPage2 As System.Windows.Forms.TabPage
    Private WithEvents groupBox5 As System.Windows.Forms.GroupBox
    Private WithEvents cbBaudRate As System.Windows.Forms.ComboBox
    Private WithEvents label5 As System.Windows.Forms.Label
    Private WithEvents txtMachineSN As System.Windows.Forms.TextBox
    Private WithEvents cbPort As System.Windows.Forms.ComboBox
    Private WithEvents label7 As System.Windows.Forms.Label
    Private WithEvents label6 As System.Windows.Forms.Label
    Private WithEvents btnRsConnect As System.Windows.Forms.Button
    Private WithEvents lblState As System.Windows.Forms.Label

End Class
